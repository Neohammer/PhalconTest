-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : lun. 21 mars 2022 à 16:10
-- Version du serveur : 5.7.19
-- Version de PHP : 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `project`
--

-- --------------------------------------------------------

--
-- Structure de la table `administrator`
--

DROP TABLE IF EXISTS `administrator`;
CREATE TABLE IF NOT EXISTS `administrator` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `login` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `password` varchar(32) NOT NULL,
  `read_only` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `administrator`
--

INSERT INTO `administrator` (`id`, `login`, `name`, `password`, `read_only`) VALUES
(7, 'account.admin@gmail.com', 'ADMINISTRATOR', '0b2494f97c58f4c34522dbf818519f1f', 0),
(8, 'account.reader@gmail.com', 'READ ONLY', '0b2494f97c58f4c34522dbf818519f1f', 1);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(70) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id`, `name`, `address`, `country`) VALUES
(2, 'TestAddClient', 'Adresse 1\r\nAdresse 2\r\nCityd', 'FR'),
(6, 'Customer#1', 'adress1 row ligne\r\nadress2 row ligne', 'PT'),
(5, 'testAutreSociété', '+$*=**', 'US');

-- --------------------------------------------------------

--
-- Structure de la table `company`
--

DROP TABLE IF EXISTS `company`;
CREATE TABLE IF NOT EXISTS `company` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(70) NOT NULL,
  `balance` int(10) UNSIGNED DEFAULT NULL,
  `country` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `company`
--

INSERT INTO `company` (`id`, `name`, `balance`, `country`) VALUES
(1, 'COMPANY-N1', 500005, 'FR'),
(3, 'My&Co', 600000, 'CA'),
(4, 'Monstre&Co', 500, 'BE');

-- --------------------------------------------------------

--
-- Structure de la table `company_products`
--

DROP TABLE IF EXISTS `company_products`;
CREATE TABLE IF NOT EXISTS `company_products` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `company_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `company_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(70) NOT NULL,
  `birthday` date DEFAULT NULL,
  `country` varchar(2) DEFAULT NULL,
  `first_day_company` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `employee`
--

INSERT INTO `employee` (`id`, `company_id`, `name`, `birthday`, `country`, `first_day_company`) VALUES
(1, 1, 'test', NULL, '', NULL),
(2, 1, 'Employee company N1', NULL, 'FR', NULL),
(3, 1, 'efsdfsfsdfdfs', NULL, 'FR', '2022-03-23'),
(4, 1, 'efsdfsfsdfdfs', NULL, '', NULL),
(5, 1, 'fsihlksdfklsd', NULL, '', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` int(10) UNSIGNED NOT NULL,
  `tax` smallint(4) UNSIGNED NOT NULL DEFAULT '20',
  `stock` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `tax`, `stock`) VALUES
(2, 'ProductAll', 52300, 2000, 5),
(3, 'ProdUI', 200, 2000, 45),
(4, 'OtherProd#123', 25000, 2000, 5000);

-- --------------------------------------------------------

--
-- Structure de la table `provider`
--

DROP TABLE IF EXISTS `provider`;
CREATE TABLE IF NOT EXISTS `provider` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(70) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `provider`
--

INSERT INTO `provider` (`id`, `name`, `address`, `country`) VALUES
(1, 'Provider 1', 'Far far away\r\nWhy not', 'US'),
(2, 'Provider #23', '101 avenue du Général Leclerc\r\n101 avenue du Général Leclerc\r\n101 avenue du Général Leclerc', 'CA');

-- --------------------------------------------------------

--
-- Structure de la table `provider_products`
--

DROP TABLE IF EXISTS `provider_products`;
CREATE TABLE IF NOT EXISTS `provider_products` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `provider_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `transaction_client`
--

DROP TABLE IF EXISTS `transaction_client`;
CREATE TABLE IF NOT EXISTS `transaction_client` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` int(10) UNSIGNED NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `transaction_client`
--

INSERT INTO `transaction_client` (`id`, `client_id`, `company_id`, `product_id`, `quantity`, `date`) VALUES
(1, 2, 1, 1, 5, '2022-03-21 14:53:57');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
